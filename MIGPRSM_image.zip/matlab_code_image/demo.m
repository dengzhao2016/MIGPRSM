% % This is the demo for decomposing the target image by our algorithm
% % for varaint K's. The parameters are sensitive, the user can change them
% % for different images
% %
clear all;
% close all;
addpath ./Images    ./utilits     ./solvers
ii=1;
% image_kind = 2;
% if image_kind == 2;
if ii==1
    %%% synthetic images %%%%
    cart = im2double(imread('baboon256.bmp'));
    text = im2double(imread('texture4.tif'));
    
    opts.cart=cart;
    opts.text=text;
    I = 0.7*cart+0.3*text;
end
if ii==2
    I = im2double(imread('barbara.png'));
end
%  I = 1*cart+0*text;
if ii==3
    %%% real images
    I = im2double(imread('barbara.png'));
    I = I(1:256,257:end);
end

kind = 1; %% 1---The case of K=I; 2---The case of K=S;

%%%%%%%%%%  the setting for the obervation x0
[n1,n2,n3]= size(I);
opts.MaxIt= 100;
opts.I    = I;
opts.Tol  = 1e-8;
r  = 11;    %%%%%%  size of patch

%%%%%%%%%%%%% The case of K=I  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if kind == 1
    OPTK = 'I';
    K    = 1;
    x0   = I;
    opts.tau1 =0.01; opts.tau2 =0.005;  opts.tau3 =1;
    
    opts.beta1=1;    opts.beta2=1;     opts.beta3=1;  opts.alpha= 1.35;
    [u1,v1,out1] = APGM(x0,K,r,opts,OPTK);
    
    opts.alpha = 1.35;
    opts.tau =(opts.alpha+2)/4;
    [u2,v2,out2] = indefinite_2block_ADMM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.6; opts.gamma = 0.5; opts.rho = 0.3;
    opts.tau =1;
    [u3,v3,out3] = IGPRSM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.6; opts.gamma = 0.5; opts.rho1 = 0.3; opts.rho2 = 0.1;
    opts.tau =1;
    [u4,v4,out4] = MIGPRSM2(x0,K,r,opts,OPTK);
end
%%%%%%%%%%%%% The case of K=S  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if kind == 2
    OPTK = 'S';
    if ii==2
        K    = floor(im2double(imread('mask2.bmp')));
    else
        K    = floor(im2double(imread('mask3.bmp')));
    end
    %
    %K    = K_temp(:,:,1);
    x0   = K.*I;
    SNR = 20*log10(norm(I(:))/norm(x0(:)-I(:)))
    
    opts.tau1  =0.003;   opts.tau2 =0.05;     opts.tau3 =1; %%%% parameters
    opts.beta1=0.008;    opts.beta2=0.008;     opts.beta3=0.00008;   opts.alpha= 1.9;
    [u1,v1,out1] = APGM(x0,K,r,opts,OPTK);
    aa=[];
    bb=[];
    CC=[];
    %     % for kk= 1:0.2:2
    opts.alpha= 1.9;
    opts.tau =(opts.alpha+2)/4;
    [u2,v2,out2] = indefinite_2block_ADMM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.2; opts.gamma =1.6; opts.rho = 0.1;
    opts.tau =1;
    [u3,v3,out3] = IGPRSM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.2; opts.gamma =1.6; opts.rho1 = 0.1; opts.rho2 = 0.01;
    opts.tau =1;
    [u4,v4,out4] = MIGPRSM2(x0,K,r,opts,OPTK);   
end

figure(1);
subplot(141); imshow(x0,[]);
subplot(142); imshow(u4,[]);
subplot(143); imshow(v4,[]);
subplot(144); imshow(u4+v4,[]);

figure(2);
subplot(141); imshow(u1+v1,[]); title('APGM')
subplot(142); imshow(u2+v2,[]); title('GLADMM')
subplot(143); imshow(u3+v3,[]); title('IGPRSM')
subplot(144); imshow(u4+v4,[]); title('MIGPR2')

figure(3);
semilogy(out1.obj,'m-*');
hold on;
semilogy(out2.obj,'k-.','LineWidth',2);
semilogy(out3.obj,'b--','LineWidth',2);
semilogy(out4.obj,'r-','LineWidth',2);
legend('APGM','GLADMM','IGPRSM','MIGPR2')
xlabel('Global iter.')
ylabel('Function values')
hold on;

figure(4);
semilogy(out1.Time,out1.obj,'m-*');
hold on;
semilogy(out2.Time,out2.obj,'k-.','LineWidth',2);
semilogy(out3.Time,out3.obj,'b--','LineWidth',2);
semilogy(out4.Time,out4.obj,'r-','LineWidth',2);
legend('APGM','GLADMM','IGPRSM','MIGPR2')
xlabel('CPU time')
ylabel('Function values')
hold on;

figure(5);
plot(out1.SNR,'m-*');
hold on;
plot(out2.SNR,'k-.','LineWidth',2);
plot(out3.SNR,'b--','LineWidth',2);
plot(out4.SNR,'r-','LineWidth',2);
legend('APGM','GLADMM','IGPRSM','MIGPR2')
xlabel('Global Iter.')
ylabel('SNR')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





