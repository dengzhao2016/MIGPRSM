function Px = Patch(x,r)
%%%%Partition (m,n) image into blocks, then realign them columnly
%%%% x  --  image
%%%% r  --  width of patch 
%%%% Px --  matrix after patching

% %  Written by Dr. Wenxing Zhang, ITAV, Toulouse, France, 2012.4.
% %  wenxing84@gmail.com.

[n1,n2,n3] = size(x);
BX  = [x,x;x,x];
N1  = ceil(n1/r);
N2  = ceil(n2/r);
Px  = zeros(r*r*n3,N1*N2);
for i=1:N1;
    for j=1:N2;
        Temp = BX((i-1)*r+1:i*r,(j-1)*r+1:j*r,:);
%         figure(1); subplot(121); imshow(x);
%         rectangle('Position', [(j-1)*r+1 (i-1)*r+1 r r],...
%             'EdgeColor','r','lineWidth',2)
%         subplot(122); imshow(Temp); pause(0.5)
        Px(:,(i-1)*N2+j)   = Temp(:);
    end
end

% imshow(fftshift(real(fft2(x))),[]);

        