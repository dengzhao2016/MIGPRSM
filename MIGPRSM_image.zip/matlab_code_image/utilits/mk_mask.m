function mask = mk_mask(nx,Num,Width,DK,DW)

%  Construct a mask with circles and strips
%
%  We assume nx is an even integer. The central pixel has index
%  
% Inputs:   nx      size of mask
%           Num     the number of circles in mask
%           Width   the width of each circle
%           Dense   the density of strips
% Output:   mask    the generated mask with circles




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% for circles
Loops = linspace(0,1,Num);   
if Width > 1/Num;
    Width = 0.8/Num;
    fprintf('use the norm width:%6.2f\n',Width);
end
hx     = 2/nx;
x      = -1:hx:1-hx;  x = x';
onevec = ones(nx,1);
mask   = sqrt((x*onevec').^2 + (onevec*x').^2);
Temp   = floor(mask*100)/100;
for i  = 1:length(Loops);
    Inx= Temp<Loops(i)&Temp>Loops(i)-Width; 
    mask(Inx)= 0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% for strips
a    = [ones(nx,DW),zeros(nx,DK),ones(nx,DW)];
Pat  = size(a);
b    = ones(1,ceil(nx/Pat(2)));
Stp  = kron(b,a);
mask = mask>0;
mask = mask.*Stp(1:nx,1:nx);



