function BX = IPatch(x,Siz)
%%%%Inverse of Patch() function
%%%% realign matrix  into an (m,n) image
%%%% x   --  image
%%%% Siz --  size of original image
%%%% Note�� P is orthan matrix, i.e., P^T*P=P^{-1}*P = identity

% %  Written by Dr. Wenxing Zhang, ITAV, Toulouse, France, 2012.4.
% %  wenxing84@gmail.com.

n1 = Siz(1);
n2 = Siz(2);
n3 = Siz(3);

[m1,m2,m3] = size(x);
r = sqrt(m1/n3); 
N1  = ceil(n1/r);
N2  = ceil(n2/r);
BX  = zeros(2*n1,2*n2,n3);
for i=1:N1;
    for j=1:N2;
        Temp = x(:,(i-1)*N2+j);
        BX((i-1)*r+1:i*r,(j-1)*r+1:j*r,:,:)=reshape(Temp,r,r,n3);
%         figure(1); subplot(121); imshow(reshape(Temp,r,r,n3));
%         subplot(122); imshow(BX(1:n1,1:n2,:));
%         rectangle('Position', [(j-1)*r+1 (i-1)*r+1 r r],...
%             'EdgeColor','r','lineWidth',2)           
    end
end
BX = BX(1:Siz(1),1:Siz(2),:);






        