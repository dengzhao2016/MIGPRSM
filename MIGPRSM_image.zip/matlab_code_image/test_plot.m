cart = im2double(imread('baboon256.bmp')); 
    text = im2double(imread('texture4.tif'));
    I1 = 0.7*cart+0.3*text;
    I2 = im2double(imread('barbara.png')); 
 %I2 = I2(257:end,257:end);
figure(1)
subplot(121);imshow(I1)
subplot(122);imshow(I2)