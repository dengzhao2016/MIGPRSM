% % This is the demo for decomposing the target image by our algorithm
% % for varaint K's. The parameters are sensitive, the user can change them
% % for different images
% %
clear all;
% close all;
addpath ./Images    ./utilits     ./solvers
ii=2;
% image_kind = 2;
% if image_kind == 2;
if ii==3
    %%% synthetic images %%%%
    cart = im2double(imread('boy.tif'));
    text = im2double(imread('texture4.tif'));
    
    %   cart = im2double(imread('TomAndJerry.png'));
    %   text = im2double(imread('wool.png'));
    opts.cart=cart;
    opts.text=text;
    I = 0.7*cart+0.3*text;
end
if ii==2
    cart = im2double(imread('TomAndJerry.png'));
    text = im2double(imread('wool.png'));
    opts.cart=cart;
    opts.text=text;
    I = 0.7*cart+0.3*text;
end
%  I = 1*cart+0*text;
if ii==1
    %%% real images
    I = im2double(imread('barbara.png'));
    I = I(257:end,257:end);
    %I = im2double(imread('weave.jpg'));
    %I = I(1:end,1:end);
end

kind = 3; %% 1---The case of K=I; 2---The case of K=S; 3---The case of K=B

%%%%%%%%%%  the setting for the obervation x0
[n1,n2,n3]= size(I);
opts.MaxIt= 100;
opts.I    = I;
opts.Tol  = 1e-8;
opts.alpha= 0.8;
r  = 11;    %%%%%%  size of patch

%%%%%%%%%%%%% The case of K=I  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if kind == 1
    OPTK = 'I';
    K    = 1;
    x0   = I;
    opts.tau1 =0.01; opts.tau2 =0.005;  opts.tau3 =1;
    opts.beta1=10;    opts.beta2=10;     opts.beta3=10;
    %
    [u00,v00,out00] = EADM(x0,K,r,opts,OPTK);
    %[u,v,out] = NEWADM(x0,K,r,opts,OPTK);
    opts.alpha= 0.9;
    %   [u00,v00,out00] = ADM-G(x0,K,r,opts,OPTK);
    opts.alpha= 0.5;
    [u0,v0,out0] = PC_ADMM(x0,K,r,opts,OPTK);
    %
    opts.beta1=1;    opts.beta2=opts.beta1;     opts.beta3=1*opts.beta1;
    [u1,v1,out1] = APGM(x0,K,r,opts,OPTK);
    % aa=[];
    % bb=[];
    % CC=[];
    
    opts.alpha = 1.35;
    opts.tau =(opts.alpha+2)/4;
    %[u2,v2,out2] = SUSLM(x0,K,r,opts,OPTK);
    [u2,v2,out2] = indefinite_2block_ADMM(x0,K,r,opts,OPTK);
    %  aa=[aa out2.ReLR(end)];
    %  bb=[bb out2.ReSP(end)];
    % % CC=[CC out2.SNR(end)];
    %  end
    %  figure(1)
    %  plot(1:0.2:2,aa-mean(aa),'r');hold on;plot(1:0.2:2,bb-mean(bb),'b');
    %  figure(2)
    %  plot(out2.ReSP,'b');hold on
    
    % cc=aa+bb;
    
%     opts.alpha = 0.6; opts.gamma = 0.5; opts.rho = 0.3; 
%     opts.tau =1;
%     [u3,v3,out3] = IGPRSM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.6; opts.gamma = 0.5; opts.rho1 = 0.1; opts.rho2 = 0.1; opts.rho3 = 0.1; opts.rho4 = 0.01; opts.rho5 = 0.01;
    opts.tau =1;
    [u3,v3,out3] = MIGPRSM5(x0,K,r,opts,OPTK);    
    
end
%%%%%%%%%%%%% The case of K=S  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if kind == 2
    OPTK = 'S';
    if ii==2
        K    = floor(im2double(imread('mask2.bmp')));
    else
        K    = floor(im2double(imread('mask3.bmp')));
    end
    %
    %K    = K_temp(:,:,1);
    x0   = K.*I;
    
    opts.tau1  =0.02;   opts.tau2 =0.01;     opts.tau3 =1; %%%% parameters
    opts.beta1 =10;      opts.beta2=10;      opts.beta3=0.1;
    opts.alpha= 0.9;
    [u00,v00,out00] = ADM_G(x0,K,r,opts,OPTK);
    opts.alpha= 0.5;
    [u0,v0,out0] = PC_ADMM(x0,K,r,opts,OPTK);
    %[u2,v2,out2] = PC_ADMM_ALPHA1(x0,K,r,opts,OPTK);
    opts.tau1  =0.003;   opts.tau2 =0.05;     opts.tau3 =1; %%%% parameters
    opts.beta1=0.008;    opts.beta2=opts.beta1;     opts.beta3=0.01*opts.beta1;
    [u1,v1,out1] = APGM(x0,K,r,opts,OPTK);
    aa=[];
    bb=[];
    CC=[];
    % for kk= 1:0.2:2
    opts.alpha= 1.9;
    opts.tau =(opts.alpha+2)/4;
    %[u2,v2,out2] = SUSLM(x0,K,r,opts,OPTK);
    [u2,v2,out2] = indefinite_2block_ADMM(x0,K,r,opts,OPTK);
    % aa=[aa out2.ReLR(end)];
    % bb=[bb out2.ReSP(end)];
    % CC=[CC out2.SNR(end)];
    % end
    
%     opts.alpha = 0.2; opts.gamma =1.6; opts.rho = 0.1;
%     opts.tau =1;
%     [u3,v3,out3] = IGPRSM(x0,K,r,opts,OPTK);
    
    opts.alpha = 0.2; opts.gamma =1.6; opts.rho1 = 0.1; opts.rho2 = 0.01; opts.rho3 = 0.01; opts.rho4 = 0.01; opts.rho5 = 0.01;
    opts.tau =1;
    [u3,v3,out3] = MIGPRSM5(x0,K,r,opts,OPTK);
    
    
end

%%%%%%%%%%%%% The case of K=H  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if kind == 3
    OPTK = 'H';
    K    = fspecial('disk',3);
    x0   = imfilter(I,K,'circular');
    opts.tau1 =0.0005;  opts.tau2 = 0.001;       opts.tau3 =1;
    opts.beta1=0.1;     opts.beta2= opts.beta1;  opts.beta3=opts.beta1;
    [u00,v00,out00] = EADM(x0,K,r,opts,OPTK);
    %[u,v,out] = NEWADM(x0,K,r,opts,OPTK);
    [u0,v0,out0] = PC_ADMM(x0,K,r,opts,OPTK);
    %[u2,v2,out2] = PC_ADMM_ALPHA1(x0,K,r,opts,OPTK);
    
    opts.beta1=0.01;    opts.beta2=opts.beta1;     opts.beta3=opts.beta1;
    [u1,v1,out1] = APGM(x0,K,r,opts,OPTK);
    opts.alpha= 1.7;
    opts.tau =(opts.alpha+2)/4;
    %[u2,v2,out2] = SUSLM(x0,K,r,opts,OPTK);
    [u2,v2,out2] = indefinite_2block_ADMM(x0,K,r,opts,OPTK);
    
%     opts.alpha = 0.2; opts.gamma =1.6; opts.rho = 0.1;
%     opts.tau =1;
%     [u3,v3,out3] = IGPRSM(x0,K,r,opts,OPTK);

    opts.alpha = 0.2; opts.gamma =1.6; opts.rho1 = 0.1;  opts.rho2 = 0.01; opts.rho3 = 0.01; opts.rho4 = 0.01; opts.rho5 = 0.01;
    opts.tau =1;
    [u3,v3,out3] = MIGPRSM5(x0,K,r,opts,OPTK);
    
end

%%%%%%%% display results
figure(1);
subplot(3,4,(ii-1)*4+1); imshow(x0,[]);
subplot(3,4,(ii-1)*4+1+1); imshow(u3,[]);
subplot(3,4,(ii-1)*4+1+2); imshow(v3,[]);
subplot(3,4,(ii-1)*4+1+3); imshow(u3+v3,[]);
hold on
% end
figure(1);
subplot(334); imshow(x0,[]); title('target image')
subplot(335); imshow(u1,[]); title('cartoon')
subplot(336); imshow(v1,[]); title('texture')

figure(1);
subplot(337); imshow(x0,[]); title('target image')
subplot(338); imshow(u3,[]); title('cartoon')
subplot(339); imshow(v3,[]); title('texture')

figure(2);
subplot(131); imshow(u2+v2,[]); title('GLADMM')
subplot(132); imshow(u1+v1,[]); title('APGM')
subplot(133); imshow(u3+v3,[]); title('IGPRSM')

figure(3);
subplot(2,3,(ii-1)+1);
semilogy(out00.obj,'m-*');
hold on;
semilogy(out2.obj,'k-.','LineWidth',2);
semilogy(out1.obj,'b--','LineWidth',2);
semilogy(out3.obj,'r-','LineWidth',2);
legend('ADM-G','GLADMM','APGM','AGPRSM')
xlabel('Iteration numbers')
ylabel('Function values')

subplot(2,3,(ii-1)+4);
semilogy(out00.Time,out00.obj,'m-');hold on;semilogy(out2.Time,out2.obj,'k');semilogy(out1.Time,out1.obj,'b');semilogy(out3.Time,out3.obj,'r');
legend('ADM-G','GLADMM','APGM','AGPRSM')
xlabel('CPU time')
ylabel('objective function values')

hold on
figure(5)
%subplot(1,3,ii);
plot(out00.SNR,'m-*');hold on;
plot(out2.SNR,'k-.','LineWidth',2);
plot(out1.SNR,'b--','LineWidth',2);
plot(out3.SNR,'r-','LineWidth',2);
legend('ADM-G','GLADMM','APGM','AGPRSM')
xlabel('Iteration numbers')
ylabel('SNR')
hold on

subplot(2,2,3);
plot(out00.ReLR,'k');hold on;plot(out2.ReLR,'k');plot(out1.ReLR,'b');plot(out3.ReLR,'r');
legend('ADM-G','GLADMM','APGM','AGPRSM')
subplot(224);
plot(out00.ReSP,'k');hold on;plot(out2.ReSP,'k');plot(out1.ReSP,'b');plot(out3.ReSP,'r');
legend('ADM-G','GLADMM','APGM','AGPRSM')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





