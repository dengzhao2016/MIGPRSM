function [u,v,out] = APGM(x0,K,r,opts,OPTK)
%%%%% Input:
%%%%%       x0   --- observed image
%%%%%       K    --- linear operator 
%%%%%       r    --- size of blocks
%%%%%       opts --- parameters for algorithm
%%%%% output:
%%%%%       u    --- cartoon
%%%%%       v    --- texture

%% S. Ma, Alternating proximal gradient method for convex minimization, 
%% J. Sci. Comput. 68 (2) (2016) 546�C572

tau1  = opts.tau1;   tau2  = opts.tau2;   tau3  = opts.tau3;
beta1 = opts.beta1;  beta2 = opts.beta2;  beta3 = opts.beta3;
alpha = opts.alpha;

MaxIt = opts.MaxIt;  I     = opts.I;      Tol   = opts.Tol;
if isfield(opts,'cart'); cart = opts.cart; else cart=zeros(size(x0));end
if isfield(opts,'text'); text = opts.text; else text=zeros(size(x0));end

[n1,n2,n3] = size(x0);
%%%%%%%%%%%%%%%%% Periodic  boundary condtion %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d1h = zeros(n1,n2,n3); d1h(1,1,:) = -1; d1h(n1,1,:) = 1; d1h = fft2(d1h);
d2h = zeros(n1,n2,n3); d2h(1,1,:) = -1; d2h(1,n2,:) = 1; d2h = fft2(d2h);
Px  = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%\nabla_1 x 
Py  = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%\nabla_2 y
PTx = @(x) [x(n1,:,:)-x(1,:,:); x(1:n1-1,:,:)-x(2:n1,:,:)]; %%\nabla_1^T x 
PTy = @(x) [x(:,n2,:)-x(:,1,:), x(:,1:n2-1,:)-x(:,2:n2,:)]; %%\nabla_2^T y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

u  = zeros(n1,n2,n3); 
v  = zeros(n1,n2,n3); 
x1 = zeros(n1,n2,n3); x2 = zeros(n1,n2,n3);
N1 = ceil(n1/r); N2  = ceil(n2/r);
y  = zeros(r*r*n3,N1*N2);
z  = zeros(n1,n2,n3); 
lbd11 = zeros(n1,n2,n3); lbd12 = zeros(n1,n2,n3);
lbd2  = zeros(size(y));
lbd3  = zeros(n1,n2,n3);
MDu   = beta1*(abs(d1h).^2+abs(d2h).^2) + beta3;



r_A1 = beta1*10;     
r_A2 = beta2*10;    
r_A3 = beta3*10;     

r_B1 = beta1*1;        
r_B2 = beta2*1;      
r_B3 = beta3*1;      





switch lower(OPTK)
    case 'i'  %%%%%%%%%%%%%%%%%%%%%%%%% K = I %%%%%%%%%%%%%%%% 
        MDz   = tau3 + r_B3;  ATf = x0;
    case 's'  %%%%%%%%%%%%%%%%%%%%%%%%% K = S %%%%%%%%%%%%%%%% 
        MDz   = tau3*K + r_B3;  ATf = K.*x0;
    case 'h'  %%%%%%%%%%%%%%%%%%%%%%%%% K = H %%%%%%%%%%%%%%%% 
        siz = size(K); center = [fix(siz(1)/2+1),fix(siz(2)/2+1)];
        P   = zeros(n1,n2,n3); for i =1:n3; P(1:siz(1),1:siz(2),i) = K; end
        D   = fft2(circshift(P,1-center));
        H   = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B x 
        HT  = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
        MDz = tau3*abs(D).^2 + r_B3;  ATf   = HT(x0);
end

obj  = zeros(1,MaxIt);   %%%% objective function value
LR   = zeros(1,MaxIt);   %%%% nuclear norm (low-rank component)
SP   = zeros(1,MaxIt);   %%%% total variation norm
Corr = zeros(1,MaxIt);   %%%% correlation of u and v
Time = zeros(1,MaxIt);   %%%% computing time
ReLR = zeros(1,MaxIt);   
ReSP = zeros(1,MaxIt);  
SNR  = zeros(1,MaxIt);



dxu= Px(u);
dyu= Py(u);


Pv  = Patch(v,r);


time = cputime;



for itr = 1:MaxIt
     
            
    %%%% update lagrange multipliers
    lbd11_0= lbd11 - beta1*(dxu-x1);
    lbd12_0= lbd12 - beta1*(dyu-x2);
    lbd2_0 = lbd2  - beta2*(Pv-y);
    lbd3_0 = lbd3  - beta3*(u+v-z);
    
    
        
    %%% step 1: \tilde u
    Temp = 1/r_A1*(PTx(lbd11_0)+PTy(lbd12_0))+1/r_A3*lbd3_0;
    un  = u + Temp;
    
   
    
    %%% step 2: \tilde v 
    Temp= 1/r_A2*IPatch(lbd2_0,[n1,n2,n3]) + 1/r_A3*lbd3_0;
    vn  = v + Temp;
% 
    %% step 1: \tilde u
%     Temp= PTx(beta1*x1+lbd11)+PTy(beta1*x2+lbd12)+beta3*(z-v)+lbd3;
%     un  = real(ifft2(fft2(Temp)./MDu));
%     
%     %% step 2: \tilde v 
%     Temp= IPatch(beta2*y+lbd2,[n1,n2,n3]) + beta3*(z-un) + lbd3;
%     vn  = Temp/(beta2+beta3);
    
    dxun= Px(un);
    dyun= Py(un);
    Pvn  = Patch(vn,r);
    
    
%      norm(un)
%      norm([PTx(dxun);PTy(dyun)])
% kkk
    
        %%%% update lagrange multipliers
    lbd11= lbd11 - beta1*(dxun-x1);
    lbd12= lbd12 - beta1*(dyun-x2);
    lbd2 = lbd2  - beta2*(Pvn-y);
    lbd3 = lbd3  - beta3*(un+vn-z);
    
    
    
    
    %%% step 3: \tilde x

    sk1 = x1 - lbd11/r_B1;
    sk2 = x2 - lbd12/r_B1;
    nsk = sqrt(sk1.^2 + sk2.^2); nsk(nsk==0)=1;
    nsk = max(1-(tau1/r_B1)./nsk,0);
    xn1 = sk1.*nsk;
    xn2 = sk2.*nsk;
        
    %%% step 4: \tilde y  
  
    Temp = y - lbd2/r_B2;
%     [U,D,VT] = mexsvd(Temp,2);  %%%%%%%%mex file SVD
    [U,D,VT] = svd(Temp,'econ');  %%%%%%%%mex file SVD
    D    = diag(D);
    ind  = find(D>tau2/r_B2);
    D    = diag(D(ind) - tau2/r_B2);
%     yn   = U(:,ind) * D * VT(ind,:);
    yn   = U(:,ind) * D * VT(:,ind)';
     
%     size(x1)
%     size(x2)
%     size(y)
%     size(z)
%     ggg
%     if choosvd(n,sv) == 1    %%%%%%%% PROPACK SVD
%         [U, D, V] = lansvd(T, sv, 'L') ; fprintf('lansvd');lh=lh+1;
%     else
%         [U, D, V] = svd(T, 'econ') ;     fprintf('fullsvd');
%     end
%     D     = diag(D);
%     ind   = find(D > 1/beta);
%     D     = diag(D(ind)-1/beta);
%     yn    = U(:,ind) * D * V(:,ind)';
%     rankr(iter)= length(ind);
%     svp = rankr(iter);
%     if svp < sv
%         sv = min(svp + 1, n) ; 
%     else
%         sv = min(svp + round(0.04*n), n) ;
%     end
        

    %%% step 5: \tilde z
    Temp = tau3*ATf + r_B3*z - lbd3;
    if lower(OPTK) == 'h'
        zn = real(ifft2(fft2(Temp)./MDz));
    else
        zn = Temp./MDz;
    end
    

    
    %%%% update lagrange multipliers
    lbd11= lbd11 - beta1*(dxun-xn1);
    lbd12= lbd12 - beta1*(dyun-xn2);
    lbd2 = lbd2  - beta2*(Pvn-yn);
    lbd3 = lbd3  - beta3*(un+vn-zn);
    
    %%%%%%%%%%%%%%%%%%%%%%% outputs  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(itr)= cputime-time;
    LR(itr)  = length(ind) ;           %%%% nuclear norm (low-rank component)
    TVun     = sqrt(dxun.^2 + dyun.^2);
    SP(itr)  = sum(TVun(:));   %%%% total variation norm
    Corr(itr)= corr(un(:),vn(:));   %%%% correlation of u and v    
    if isfield(opts,'cart'); ReLR(itr)= norm(un(:)-cart(:),'fro')/norm(cart(:),'fro'); end
    if isfield(opts,'text'); ReSP(itr)= norm(vn(:)-text(:),'fro')/norm(text(:),'fro'); end
    switch lower(OPTK)
        case 'i'  %%%%%%%%%%%%%%%%%%%%%%%%% K = I %%%%%%%%%%%%%%%% 
            Kuvn = un+vn;
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
        case 's'  %%%%%%%%%%%%%%%%%%%%%%%%% K = S %%%%%%%%%%%%%%%% 
            Kuvn = K.*(un+vn);
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
        case 'h'  %%%%%%%%%%%%%%%%%%%%%%%%% K = H %%%%%%%%%%%%%%%% 
            Kuvn = H(un+vn);
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
    end
    obj(itr) = tau1*SP(itr)+tau2*sum(diag(D))+0.5*tau3*norm(Kuvn(:)-x0(:))^2;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%% stopping rule
   % rev=v-vn;  rex1=x1-xn1; rex2=x2-xn2; rey=y-yn; rez=z-zn;
   % if obj(itr)/(n1*n2*n3)<Tol; 
   if mod(itr,20) == 1
%         fprintf('It=%d,cpu=%4.2f,snr=%4.2f,obj=%4.2f\n',itr-1,Time(itr-1),SNR(itr-1),obj(itr-1)); 
      fprintf('It=%d,cpu=%4.2e,snr=%4.2e,obj=%4.2e\n',itr,Time(itr),SNR(itr),obj(itr)); 
   %     break; 
    end    

    u = un ; v = vn; 
    x1= xn1; x2=xn2; y=yn; z=zn;
    dxu = dxun; dyu = dyun; Pv  = Pvn;
  

    
    
    
end

out.Time = Time;
out.LR   = LR;
out.SP   = SP;
out.Corr = Corr;
out.obj  = obj;
out.ReLR = ReLR;
out.ReSP = ReSP;
out.SNR  = SNR;
