function [u,v,out] = MIGPRSM3(x0,K,r,opts,OPTK)
%%%%% Input:
%%%%%       x0   --- observed image
%%%%%       K    --- linear operator
%%%%%       r    --- size of blocks
%%%%%       opts --- parameters for algorithm
%%%%% output:
%%%%%       u    --- cartoon
%%%%%       v    --- texture

%%Written by Zhao Deng.

tau1  = opts.tau1;   tau2  = opts.tau2;   tau3  = opts.tau3;
beta1 = opts.beta1;  beta2 = opts.beta2;  beta3 = opts.beta3;
alpha = opts.alpha;  gamma = opts.gamma;  rho1 = opts.rho1;  rho2 = opts.rho2; rho3 = opts.rho3;  

MaxIt = opts.MaxIt;  I     = opts.I;      Tol   = opts.Tol;
if isfield(opts,'cart'); cart = opts.cart; else cart=zeros(size(x0));end
if isfield(opts,'text'); text = opts.text; else text=zeros(size(x0));end

[n1,n2,n3] = size(x0);
%%%%%%%%%%%%%%%%% Periodic  boundary condtion %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d1h = zeros(n1,n2,n3); d1h(1,1,:) = -1; d1h(n1,1,:) = 1; d1h = fft2(d1h);
d2h = zeros(n1,n2,n3); d2h(1,1,:) = -1; d2h(1,n2,:) = 1; d2h = fft2(d2h);
Px  = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%\nabla_1 x
Py  = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%\nabla_2 y
PTx = @(x) [x(n1,:,:)-x(1,:,:); x(1:n1-1,:,:)-x(2:n1,:,:)]; %%\nabla_1^T x
PTy = @(x) [x(:,n2,:)-x(:,1,:), x(:,1:n2-1,:)-x(:,2:n2,:)]; %%\nabla_2^T y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
u  = zeros(n1,n2,n3);
v  = zeros(n1,n2,n3);
x1 = zeros(n1,n2,n3); x2 = zeros(n1,n2,n3);
N1 = ceil(n1/r); N2  = ceil(n2/r);
y  = zeros(r*r*n3,N1*N2);
z  = zeros(n1,n2,n3);
lbd11 = zeros(n1,n2,n3); lbd12 = zeros(n1,n2,n3);
lbd2  = zeros(size(y));
lbd3  = zeros(n1,n2,n3);
MDu   = beta1*(abs(d1h).^2+abs(d2h).^2) + beta3;

u_2  = u;
v_2  = v;
x1_2 = x1; x2_2 = x2;
y_2  = y;
z_2  = z;
lbd11_2 = lbd11; lbd12_2 = lbd12;
lbd2_2  = lbd2;
lbd3_2  = lbd3;

u_1  = u;
v_1  = v;
x1_1 = x1; x2_1 = x2;
y_1  = y;
z_1  = z;
lbd11_1 = lbd11; lbd12_1 = lbd12;
lbd2_1  = lbd2;
lbd3_1  = lbd3;

u0  = u;
v0  = v;
x10 = x1; x20 = x2;
y0  = y;
z0  = z;
lbd110 = lbd11; lbd120 = lbd12;
lbd20  = lbd2;
lbd30  = lbd3;

u1  = zeros(n1,n2,n3);
v1  = zeros(n1,n2,n3);
x11 = zeros(n1,n2,n3); x21 = zeros(n1,n2,n3);
N1 = ceil(n1/r); N2  = ceil(n2/r);
y1  = zeros(r*r*n3,N1*N2);
z1  = zeros(n1,n2,n3);
lbd111 = zeros(n1,n2,n3); lbd121 = zeros(n1,n2,n3);
lbd21  = zeros(size(y));
lbd31  = zeros(n1,n2,n3);

tau = opts.tau;

r_A1 = beta1*10;      tau_A1 = tau*r_A1+0.00001;
r_A2 = beta2*10;      tau_A2 = tau*r_A2+0.00001;
r_A3 = beta3*10;      tau_A3 = tau*r_A3+0.00001;

r_B1 = beta1*1;     tau_B1 = tau*r_B1+0.00001;
r_B2 = beta2*1;     tau_B2 = tau*r_B2+0.00001;
r_B3 = beta3*1;     tau_B3 = tau*r_B3+0.00001;

switch lower(OPTK)
    case 'i'  %%%%%%%%%%%%%%%%%%%%%%%%% K = I %%%%%%%%%%%%%%%%
        MDz   = tau3 + tau_B3;  ATf = x0;
    case 's'  %%%%%%%%%%%%%%%%%%%%%%%%% K = S %%%%%%%%%%%%%%%%
        MDz   = tau3*K + tau_B3;  ATf = K.*x0;
    case 'h'  %%%%%%%%%%%%%%%%%%%%%%%%% K = H %%%%%%%%%%%%%%%%
        siz = size(K); center = [fix(siz(1)/2+1),fix(siz(2)/2+1)];
        P   = zeros(n1,n2,n3); for i =1:n3; P(1:siz(1),1:siz(2),i) = K; end
        D   = fft2(circshift(P,1-center));
        H   = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B x
        HT  = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
        MDz = tau3*abs(D).^2 + tau_B3;  ATf   = HT(x0);
end

obj  = zeros(1,MaxIt);   %%%% objective function value
LR   = zeros(1,MaxIt);   %%%% nuclear norm (low-rank component)
SP   = zeros(1,MaxIt);   %%%% total variation norm
Corr = zeros(1,MaxIt);   %%%% correlation of u and v
Time = zeros(1,MaxIt);   %%%% computing time
ReLR = zeros(1,MaxIt);
ReSP = zeros(1,MaxIt);
SNR  = zeros(1,MaxIt);

dxu= Px(u);
dyu= Py(u);
Pv  = Patch(v,r);

time = cputime;

for itr = 1:MaxIt
    
    %%% inertial
    u = u1 + (rho1+rho2+rho3)*(u1 - u0) + (rho2+rho3)*(u0 - u_1) + rho3*(u_1 - u_2);
    v = v1 + (rho1+rho2+rho3)*(v1 - v0) + (rho2+rho3)*(v0 - v_1) + rho3*(v_1 - v_2);
    x1 = x11 + (rho1+rho2+rho3)*(x11 - x10) + (rho2+rho3)*(x10 - x1_1) + rho3*(x1_1 - x1_2);
    x2 = x21 + (rho1+rho2+rho3)*(x21 - x20) + (rho2+rho3)*(x20 - x2_1) + rho3*(x2_1 - x2_2);
    y = y1 + (rho1+rho2+rho3)*(y1 - y0) + (rho2+rho3)*(y0 - y_1) + rho3*(y_1 - y_2);
    z = z1 + (rho1+rho2+rho3)*(z1 - z0) + (rho2+rho3)*(z0 - z_1) + rho3*(z_1 - z_2);
    lbd11 = lbd111 + (rho1+rho2+rho3)*(lbd111 - lbd110) + (rho2+rho3)*(lbd110 - lbd11_1) + rho3*(lbd11_1 - lbd11_2);
    lbd12 = lbd121 + (rho1+rho2+rho3)*(lbd121 - lbd120) + (rho2+rho3)*(lbd120 - lbd12_1) + rho3*(lbd12_1 - lbd12_2);
    lbd2 = lbd21 + (rho1+rho2+rho3)*(lbd21 - lbd20) + (rho2+rho3)*(lbd20 - lbd2_1) + rho3*(lbd2_1 - lbd2_2);
    lbd3 = lbd31 + (rho1+rho2+rho3)*(lbd31 - lbd30) + (rho2+rho3)*(lbd30 - lbd3_1) + rho3*(lbd3_1 - lbd3_2);
    
    lbd11old=lbd11;
    lbd12old=lbd12;
    lbd2old=lbd2;
    lbd3old=lbd3;
    
    %%%% update lagrange multipliers
    lbd11_0= lbd11old - beta1*(dxu-x1);
    lbd12_0= lbd12old - beta1*(dyu-x2);
    lbd2_0 = lbd2old  - beta2*(Pv-y);
    lbd3_0 = lbd3old  - beta3*(u+v-z);
    
    %%% step 1: \tilde u
    Temp = 1/tau_A1*(PTx(lbd11_0)+PTy(lbd12_0))+1/tau_A3*lbd3_0;
    un  = u + Temp;
    
    %%% step 2: \tilde v
    Temp= 1/tau_A2*IPatch(lbd2_0,[n1,n2,n3]) + 1/tau_A3*lbd3_0;
    vn  = v + Temp;
    %
    %     %% step 1: \tilde u
    %     Temp= PTx(beta1*x1+lbd11)+PTy(beta1*x2+lbd12)+beta3*(z-v)+lbd3;
    %     un  = real(ifft2(fft2(Temp)./MDu));
    %
    %     %% step 2: \tilde v
    %     Temp= IPatch(beta2*y+lbd2,[n1,n2,n3]) + beta3*(z-un) + lbd3;
    %     vn  = Temp/(beta2+beta3);
    
    dxun= Px(un);
    dyun= Py(un);
    Pvn  = Patch(vn,r);
    
    %      norm(un)
    %      norm([PTx(dxun);PTy(dyun)])
    % kkk
    
    %%%% update lagrange multipliers
    lbd11= lbd11old - alpha*beta1*(dxun-x1);
    lbd12= lbd12old - alpha*beta1*(dyun-x2);
    lbd2 = lbd2old  - alpha*beta2*(Pvn-y);
    lbd3 = lbd3old  - alpha*beta3*(un+vn-z);
    
    %%% step 3: \tilde x
    sk1 = x1 - (lbd11-gamma/alpha*(lbd11old-lbd11))/tau_B1;
    sk2 = x2 - (lbd12-gamma/alpha*(lbd12old-lbd12))/tau_B1;
    nsk = sqrt(sk1.^2 + sk2.^2); nsk(nsk==0)=1;
    nsk = max(1-(tau1/tau_B1)./nsk,0);
    xn1 = sk1.*nsk;
    xn2 = sk2.*nsk;
    
    %%% step 4: \tilde y
    Temp = y - (lbd2-gamma/alpha*(lbd2old-lbd2))/tau_B2;
    %     [U,D,VT] = mexsvd(Temp,2);  %%%%%%%%mex file SVD
    [U,D,VT] = svd(Temp,'econ');  %%%%%%%%mex file SVD
    D    = diag(D);
    ind  = find(D>tau2/tau_B2);
    D    = diag(D(ind) - tau2/tau_B2);
    %     yn   = U(:,ind) * D * VT(ind,:);
    yn   = U(:,ind) * D * VT(:,ind)';
    
    %     size(x1)
    %     size(x2)
    %     size(y)
    %     size(z)
    %     ggg
    %     if choosvd(n,sv) == 1    %%%%%%%% PROPACK SVD
    %         [U, D, V] = lansvd(T, sv, 'L') ; fprintf('lansvd');lh=lh+1;
    %     else
    %         [U, D, V] = svd(T, 'econ') ;     fprintf('fullsvd');
    %     end
    %     D     = diag(D);
    %     ind   = find(D > 1/beta);
    %     D     = diag(D(ind)-1/beta);
    %     yn    = U(:,ind) * D * V(:,ind)';
    %     rankr(iter)= length(ind);
    %     svp = rankr(iter);
    %     if svp < sv
    %         sv = min(svp + 1, n) ;
    %     else
    %         sv = min(svp + round(0.04*n), n) ;
    %     end
    
    %%% step 5: \tilde z
    Temp = tau3*ATf+tau_B3*z - (lbd3-gamma/alpha*(lbd3old-lbd3));
    if lower(OPTK) == 'h'
        zn = real(ifft2(fft2(Temp)./MDz));
    else
        zn = Temp./MDz;
    end
    
    %%%% update lagrange multipliers
    lbd11n= lbd11 - beta1*(gamma*(dxun-x1)+(x1-xn1));
    lbd12n= lbd12 - beta1*(gamma*(dyun-x2)+(x2-xn2));
    lbd2n = lbd2  - beta2*(gamma*(Pvn-y)+(y-yn));
    lbd3n = lbd3  - beta3*(gamma*(un+vn-z)+(z-zn));
    
    %%%%%%%%%%%%%%%%%%%%%%% outputs  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(itr)= cputime-time;
    LR(itr)  = length(ind) ;           %%%% nuclear norm (low-rank component)
    TVun     = sqrt(dxun.^2 + dyun.^2);
    SP(itr)  = sum(TVun(:));   %%%% total variation norm
    Corr(itr)= corr(un(:),vn(:));   %%%% correlation of u and v
    if isfield(opts,'cart'); ReLR(itr)= norm(un(:)-cart(:),'fro')/norm(cart(:),'fro'); end
    if isfield(opts,'text'); ReSP(itr)= norm(vn(:)-text(:),'fro')/norm(text(:),'fro'); end
    switch lower(OPTK)
        case 'i'  %%%%%%%%%%%%%%%%%%%%%%%%% K = I %%%%%%%%%%%%%%%%
            Kuvn = un+vn;
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
        case 's'  %%%%%%%%%%%%%%%%%%%%%%%%% K = S %%%%%%%%%%%%%%%%
            Kuvn = K.*(un+vn);
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
        case 'h'  %%%%%%%%%%%%%%%%%%%%%%%%% K = H %%%%%%%%%%%%%%%%
            Kuvn = H(un+vn);
            SNR(itr) = 20*log10(norm(I(:))/norm(un(:)+vn(:)-I(:)));
    end
    obj(itr) = tau1*SP(itr)+tau2*sum(diag(D))+0.5*tau3*norm(Kuvn(:)-x0(:))^2;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%% stopping rule
    % rev=v-vn;  rex1=x1-xn1; rex2=x2-xn2; rey=y-yn; rez=z-zn;
    % if obj(itr)/(n1*n2*n3)<Tol;
    if mod(itr,20) == 1
        %         fprintf('It=%d,cpu=%4.2f,snr=%4.2f,obj=%4.2f\n',itr-1,Time(itr-1),SNR(itr-1),obj(itr-1));
        fprintf('It=%d,cpu=%4.2e,snr=%4.2e,obj=%4.2e\n',itr,Time(itr),SNR(itr),obj(itr));
        %     break;
    end
    
    u_2  = u_1;
    v_2  = v_1;
    x1_2 = x1_1; 
    x2_2 = x2_1;
    y_2  = y_1;
    z_2  = z_1;
    lbd11_2 = lbd11_1; 
    lbd12_2 = lbd12_1;
    lbd2_2  = lbd2_1;
    lbd3_2  = lbd3_1;
    
    u_1  = u0;
    v_1  = v0;
    x1_1 = x10; 
    x2_1 = x20;
    y_1  = y0;
    z_1  = z0;
    lbd11_1 = lbd110; 
    lbd12_1 = lbd120;
    lbd2_1  = lbd20;
    lbd3_1  = lbd30;
    
    u0  = u1;
    v0  = v1;
    x10 = x11; 
    x20 = x21;
    y0  = y1;
    z0  = z1;
    lbd110 = lbd111; 
    lbd120 = lbd121;
    lbd20  = lbd21;
    lbd30  = lbd31;
    
    u1 = un ;
    v1 = vn;
    x11= xn1;
    x21=xn2;
    y1=yn;
    z1=zn;
    lbd111 = lbd11n;
    lbd121 = lbd12n;
    lbd21 = lbd2n;
    lbd31 = lbd3n;
    
    dxu = dxun;
    dyu = dyun;
    Pv  = Pvn;
    
end

out.Time = Time;
out.LR   = LR;
out.SP   = SP;
out.Corr = Corr;
out.obj  = obj;
out.ReLR = ReLR;
out.ReSP = ReSP;
out.SNR  = SNR;
