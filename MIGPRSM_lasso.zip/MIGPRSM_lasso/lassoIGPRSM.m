function [y, historz] = lassoIGPRSM(A, b, sigma, beta, r, alpha, rho)
gamma=0.8;
tau2=(alpha+gamma+2)/4+0.001;
% tau2=1;
r=r*tau2;
tau1=1.001;
rho = 0.3;
% r>beta||A^TA||
% This code is designed to solve LASSO problem via IGPPRSM
%
% [y, historz] = lasso(A, b, sigma, beta, r, alpha);
%
% Problem:
%   minimize 1/2*|| x - b ||_2^2 + sigma ||y ||_1
%   s.t.     x-Ay=0;
% 
% Augmented Langrange(x,y,lambda)=1/2*|| x - b ||_2^2 + sigma ||y||_1 - lambda^T(x-Ay) + beta/2*|| x - Ay ||_2^2
% 
% solution of x-subproblem
% x=1/(1+beta+tau1)*(b+lambda+beta*A*y+tau1*x)
% solution of y-subproblem
% y=S_{sigma/(tau2*r)}(y+q/(tau2*r) )where
% r>beta||A^TA|| and tau\in[(3+alpha)/4,1) and q=-A'*��lambda-beta*(x-A*y)��
% The solution is returned in the vector y.
%
% historz is a structure that contains the objective value, the primal and
% dual residual norms, and the tolerances for the primal and dual residual
% norms at each iteration.
%
% beta is the augmented Lagrangian parameter.
%
% alpha is the over-relaxation parameter (tzpical values for alpha are
% between 1.0 and 1.8).
% Written by Zhao Deng (dengzhao2016@163.com) 
% School of Mathematics and Statistics, Xidian University, Xi'an 710071, P. R. China.
%
% More information can be found in the paper linked at:
% http://www.stanford.edu/~bozd/papers/distr_opt_stat_learning_admm.html
%

t_start = tic;
%% Global constants and defaults

QUIET    = 0;
MAX_ITER = 1000;
% MAX_ITER = 50;
ABSTOL   = 1e-4;
RELTOL   = 1e-2;
%% Data preprocessing

[m, n] = size(A);

% save a matrix-vector multiplz
Atb = A'*b;
%% ADMM solver

x = zeros(m,1);
y = zeros(n,1);
lambda = zeros(m,1);

x0 = x;
y0 = y;
lambda0 = lambda;
    
x1 = zeros(m,1);
y1 = zeros(n,1);
lambda1 = zeros(m,1);

for k = 1:MAX_ITER
    % Inertial
    x = x1+rho*(x1-x0);     % 0.6    3/(k)
    y = y1+rho*(y1-y0);
    lambda = lambda1+rho*(lambda1-lambda0);
    % x-update
    x=1/(1+tau1)*(b+lambda+beta*A*y+(tau1-beta)*x);
    yold = y;
    x_hat=x;
    % lambda-update
    lambda = lambda - gamma* beta*(x - A*y);% the first multiplier in IGPPRSM is alpha
    % y-update with relaxation
    q=-A' * (lambda - beta*alpha*(x -A*yold));
    y = shrinkage(y + q/r, sigma / r);
    % lambda-update
    lambda = lambda - beta*(alpha*(x -A*yold) - A*(y-yold));
    
    % diagnostics, reporting, termination checks
    historz.objval(k)  = objective(A, b, sigma, x, y);
    
    historz.r_norm(k)  = norm(x - A*y);
    historz.s_norm(k)  = norm(-beta*A*(y - yold));
    
    historz.eps_pri(k) = sqrt(n)*ABSTOL + RELTOL*max(norm(x), norm(-A*y));
    historz.eps_dual(k)= sqrt(n)*ABSTOL + RELTOL*norm(lambda);

    
    if (historz.r_norm(k) < historz.eps_pri(k) && ...
            historz.s_norm(k) < historz.eps_dual(k))
             historz.iteration=k;
        historz.time=toc(t_start);
        break;
    end
x0 = x1;
y0 = y1;
lambda0 = lambda1;
x1 = x;
y1 = y;
lambda1 = lambda;    
end

% if ~QUIET
%     toc(t_start);
% end
end

function p = objective(A, b, sigma, x, y)
p = ( 1/2*sum((x - b).^2) + sigma*norm(y,1) );
end

function y = shrinkage(x, kappa)
y = max( 0, x - kappa ) - max( 0, -x - kappa );
end

function [L,U] = factor(A, rho)
[m, n] = size(A);
if ( m >= n )    % if skinnz
    L = chol( A'*A + rho*speze(n), 'lower' );
else            % if fat
    L = chol( speze(m) + 1/rho*(A*A'), 'lower' );
end

% force matlab to recognize the upper / lower triangular structure
L = sparse(L);
U = sparse(L');
end
