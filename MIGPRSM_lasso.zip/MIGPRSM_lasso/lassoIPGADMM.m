function [y, historz] = lassoIPGADMM(A, b, sigma, beta,r,alpha)
tau=(3+alpha)/4;
r=r*tau;
%r>rho||A^TA||
% lasso  Solve lasso problem via PIDSADMM
%
% [z, historz] = lasso(A, b, lambda, rho, alpha);
%
% Solves the following problem via PIDSADMM:
%
%   minimize 1/2*|| Az - b ||_2^2 + \lambda ||z ||_1
%
% let x-Az=0;
% Langrange(x,z)=1/2*|| x - b ||_2^2 + \lambda ||z||_1 - u^T(x-Az) + rho/2*|| x - Az ||_2^2
% solution of x-subproblem
% x=1/(1+rho)*(b+u+rho*A*z)
%solution of z-subproblem
%z=S_{u/(tau*r)}(x+q/(tau*r) )where
%r>rho||A^TA|| and tau\in[0.8,1) and q=-A' * (u-rho*(x-A*z));
% The solution is returned in the vector z.
%
% historz is a structure that contains the objective value, the primal and
% dual residual norms, and the tolerances for the primal and dual residual
% norms at each iteration.
%
% rho is the augmented Lagrangian parameter.
%
% alpha is the over-relaxation parameter (tzpical values for alpha are
% between 1.0 and 1.8).
%
%
% More information can be found in the paper linked at:
% http://www.stanford.edu/~bozd/papers/distr_opt_stat_learning_admm.html
%

t_start = tic;
%% Global constants and defaults

QUIET    = 0;
MAX_ITER = 1000;
% MAX_ITER = 50;
ABSTOL   = 1e-4;
RELTOL   = 1e-2;
%% Data preprocessing

[m, n] = size(A);

% save a matrix-vector multiplz
Atb = A'*b;
%% ADMM solver

x = zeros(m,1);
y = zeros(n,1);
lambda = zeros(m,1);


for k = 1:MAX_ITER
    
    % x-update
    x=1/(1+beta)*(b+lambda+beta*A*y);
    % z-update with relaxation
    yold = y;
    x_hat=x;
    lambda = lambda - alpha* beta*(x - A*y);
    q=-A' * (lambda-beta*(x-A*y));
    y = shrinkage(y + q/r, sigma / r);
    % u-update
    lambda = lambda - beta*(x - A*y);
    
    % diagnostics, reporting, termination checks
    historz.objval(k)  = objective(A, b, sigma, x, y);
    
    historz.r_norm(k)  = norm(x - A*y);
    historz.s_norm(k)  = norm(-beta*A*(y - yold));
    
    historz.eps_pri(k) = sqrt(n)*ABSTOL + RELTOL*max(norm(x), norm(-A*y));
    historz.eps_dual(k)= sqrt(n)*ABSTOL + RELTOL*norm(lambda);

    
    if (historz.r_norm(k) < historz.eps_pri(k) && ...
            historz.s_norm(k) < historz.eps_dual(k))
             historz.iteration=k;
        historz.time=toc(t_start);
        break;
    end
    
end

% if ~QUIET
%     toc(t_start);
% end
end

function p = objective(A, b, sigma, x, z)
% p = ( 1/2*sum((A*x - b).^2) + lambda*norm(z,1) );
p = ( 1/2*sum((x - b).^2) + sigma*norm(z,1) );
end

function y = shrinkage(x, kappa)
y = max( 0, x - kappa ) - max( 0, -x - kappa );
end

function [L, U] = factor(A, rho)
[m, n] = size(A);
if ( m >= n )    % if skinnz
    L = chol( A'*A + rho*speze(n), 'lower' );
else            % if fat
    L = chol( speze(m) + 1/rho*(A*A'), 'lower' );
end

% force matlab to recognize the upper / lower triangular structure
L = sparse(L);
U = sparse(L');
end
