clear; close all; clc;
rand('seed', 0);
randn('seed', 0);
mm = 150;       % number of examples
nn = 500;       % number of features
% pp = 100/n;      % sparsity density
dimension=5;
fun_num = 5;
fun_arr = {'lassoIPGADMM','lassoIGPRSM','lassoMIGPRSM2','lassoMIGPRSM3','lassoMIGPRSM4'};
alpha_arr = [0.3, 0.8];
alpha_num = length(alpha_arr);
time_arr = zeros(dimension,fun_num,alpha_num);
iter_arr = time_arr;
for di=1:dimension
    m=mm+(di-1)*200+750;
    n=nn+(di-1)*1000+2500;
    p=100/n;
    x0 = sprandn(n,1,p);
    A = randn(m,n);
    A = A*spdiags(1./sqrt(sum(A.^2))',0,n,n); % normalize columns
    ATA=A'*A;
    b = A*x0 + sqrt(0.001)*randn(m,1);
    sigma_max = norm( A'*b, 'inf' );
    sigma = 0.1*sigma_max;
    [v,d]=eigs(ATA);
    r=max(d(:));
    for ai = 1:alpha_num
        alpha = alpha_arr(ai);
        for fi = 1:fun_num
            func = str2func(fun_arr{fi});
            [~,history] = func(A, b, sigma, 1.0,r,alpha);
            time_arr(di,fi,ai) = history.time;
            iter_arr(di,fi,ai) = history.iteration;
        end
    end
end

%% ����ͼ
shape_arr = 'sdp+*';
color_arr = 'mkgrb';
line_sty = {':s',':p','-d','-+','-.*'};
for ai = 1:alpha_num
    alpha = alpha_arr(ai);
    figure(ai)
    %plot(iter_arr(:,:,ai),'-s','linewidth',3);
    hold on
    for i = 1:5
        %plot(iter_arr(:,i,ai),['-' shape_arr(i)],'color',color_arr(i),'linewidth',3);
        plot(iter_arr(:,i,ai),line_sty{i},'color',color_arr(i),'linewidth',2);
    end
    box on
    xlabel('Dimension of A','fontsize',12);
    set(gca,'YTick',0:2:50)
    set(gca,'XTick',1:5)
    set(gca,'XTickLabel',{'900x3000','1100x4000','1300x5000','1500x6000','1700x7000'})
    ylabel('Iteration numbers');
    legend('IPGADMM','IGPRSM','MIGPR2','MIGPR3','MIGPR4');
    title(['\alpha = ' num2str(alpha)]);
end



